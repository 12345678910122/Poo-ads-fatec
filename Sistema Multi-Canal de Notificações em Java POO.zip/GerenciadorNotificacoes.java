import java.util.ArrayList;
import java.util.List;

public class GerenciadorNotificacoes {
    public static void main(String[] args) {
        List<CanalNotificacao> notificacoes = new ArrayList<>();

        notificacoes.add(new Email("usuario@example.com", "Olá, este é um e-mail de teste.", "Teste de E-mail"));
        notificacoes.add(new SMS("5511987654321", "Sua encomenda foi enviada!", 1198765432));
        notificacoes.add(new WhatsApp("5511912345678", "Sua mesa está pronta!", "Enviado"));

        for (CanalNotificacao canal : notificacoes) {
            canal.enviar();
        }
    }
}
