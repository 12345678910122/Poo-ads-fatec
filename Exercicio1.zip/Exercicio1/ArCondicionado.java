public class ArCondicionado {
    private String marca;
    private String modelo;
    private int temperatura;
    private boolean ligado;

    public ArCondicionado() {
        // Construtor padrão
    }

    public ArCondicionado(String marca, String modelo, int temperatura, boolean ligado) {
        setMarca(marca);
        this.modelo = modelo;
        setTemperatura(temperatura);
        this.ligado = ligado;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        if (marca != null && marca.length() >= 3) {
            this.marca = marca;
        } else {
            System.out.println("Marca inválida: deve ter pelo menos 3 caracteres.");
        }
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        if (temperatura >= 16 && temperatura <= 30) {
            this.temperatura = temperatura;
        } else {
            System.out.println("Temperatura fora da faixa: deve ser entre 16 e 30 graus.");
        }
    }

    public boolean isLigado() {
        return ligado;
    }

    public void setLigado(boolean ligado) {
        this.ligado = ligado;
    }

    public void ativarModoTurbo() {
        if (verificarCompressor()) {
            System.out.println("Compressor OK. Ativando Modo Turbo.");
            setTemperatura(16); // Ajusta para a temperatura mínima
        } else {
            System.out.println("Falha no compressor. Não foi possível ativar o Modo Turbo.");
        }
    }

    private boolean verificarCompressor() {
        // Simula uma checagem: se o número for maior que 2, retorna true
        return Math.random() * 10 > 2;
    }

    @Override
    public String toString() {
        return "Ar Condicionado [Marca: " + marca + ", Modelo: " + modelo +
               ", Temperatura: " + temperatura + "°C, Ligado: " + (ligado ? "Sim" : "Não") + "]";
    }
}
