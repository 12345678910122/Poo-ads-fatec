public class TesteSistemas {
    public static void main(String[] args) {
        System.out.println("--- Teste Ar-Condicionado ---");
        ArCondicionado ar = new ArCondicionado("Samsung", "WindFree", 22, true);
        System.out.println(ar);
        
        System.out.println("\nTentando temperatura inválida (35°C):");
        ar.setTemperatura(35);
        
        System.out.println("\nAtivando Modo Turbo:");
        ar.ativarModoTurbo();
        System.out.println(ar);

        System.out.println("\n--- Teste Drone ---");
        Drone drone = new Drone("DRN-001", 0, 85, false);
        System.out.println(drone);
        
        System.out.println("\nTentando decolar:");
        drone.decolar();
        
        if (drone.isEmVoo()) {
            System.out.println("\nSubindo 50 metros:");
            drone.subir(50);
            
            System.out.println("\nTentando subir acima do limite (mais 100 metros):");
            drone.subir(100);
            
            System.out.println("\nDescendo 30 metros:");
            drone.descer(30);
        }
        
        System.out.println("\nEstado final do Drone:");
        System.out.println(drone);
    }
}
