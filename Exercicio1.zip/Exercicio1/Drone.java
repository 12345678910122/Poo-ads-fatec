public class Drone {
    private String codigo;
    private float altura;
    private int bateria;
    private boolean emVoo;

    public Drone(String codigo, float altura, int bateria, boolean emVoo) {
        this.codigo = codigo;
        setAltura(altura);
        setBateria(bateria);
        this.emVoo = emVoo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        if (altura >= 0 && altura <= 120) {
            this.altura = altura;
        } else {
            System.out.println("Aviso: Altura inválida. O drone não pode voar abaixo de 0m nem acima de 120m.");
        }
    }

    public int getBateria() {
        return bateria;
    }

    public void setBateria(int bateria) {
        if (bateria >= 0 && bateria <= 100) {
            this.bateria = bateria;
        } else {
            System.out.println("Aviso: Nível de bateria inválido. Deve estar entre 0 e 100%.");
        }
    }

    public boolean isEmVoo() {
        return emVoo;
    }

    public void setEmVoo(boolean emVoo) {
        this.emVoo = emVoo;
    }

    public void decolar() {
        if (this.bateria > 20) {
            if (testarMotores()) {
                this.emVoo = true;
                setAltura(2.0f); // Define altura inicial para 2 metros após decolar
                System.out.println("Drone " + this.codigo + " decolou com sucesso! Altura atual: " + this.altura + "m.");
            } else {
                System.out.println("Falha na decolagem: Motores não estão prontos.");
            }
        } else {
            System.out.println("Falha na decolagem: Bateria abaixo de 20%.");
        }
    }

    private boolean testarMotores() {
        System.out.println("Testando hélices...");
        System.out.println("Calibrando GPS...");
        // Simula uma checagem: se o número for menor que 8, os motores estão prontos.
        return Math.random() * 10 < 8;
    }

    public void subir(float x) {
        if (this.emVoo) {
            setAltura(this.altura + x);
            System.out.println("Drone " + this.codigo + " subiu para " + this.altura + "m.");
        } else {
            System.out.println("Drone " + this.codigo + " não está em voo para subir.");
        }
    }

    public void descer(float x) {
        if (this.emVoo) {
            setAltura(this.altura - x);
            System.out.println("Drone " + this.codigo + " desceu para " + this.altura + "m.");
        } else {
            System.out.println("Drone " + this.codigo + " não está em voo para descer.");
        }
    }

    @Override
    public String toString() {
        return "Drone [Código: " + codigo + ", Altura: " + altura + "m, Bateria: " + bateria +
               "%, Em Voo: " + (emVoo ? "Sim" : "Não") + "]";
    }
}
